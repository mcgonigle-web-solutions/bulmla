<?php
/**
 * @package    Joomla.Site
 * @subpackage Template.bulmla
 *
 * @author     Patrick McGonigle <patrick@mcgonigle.dev>
 * @copyright  McGonigle
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * @link       www.mcgonigle.dev
 */

defined('_JEXEC') or die;

<section class="hero is-fullheight-with-navbar">

</section>
